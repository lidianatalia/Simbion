--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = sitikop, pg_catalog;

ALTER TABLE ONLY sitikop.tiket DROP CONSTRAINT tiket_id_seating_fkey;
ALTER TABLE ONLY sitikop.tiket DROP CONSTRAINT tiket_id_jadwal_fkey;
ALTER TABLE ONLY sitikop.seating DROP CONSTRAINT seating_no_studio_fkey;
ALTER TABLE ONLY sitikop.pemesanan DROP CONSTRAINT pemesanan_id_tiket_fkey;
ALTER TABLE ONLY sitikop.pemesanan DROP CONSTRAINT pemesanan_email_member_fkey;
ALTER TABLE ONLY sitikop.jadwal DROP CONSTRAINT jadwal_id_film_fkey;
SET search_path = siresto, pg_catalog;

ALTER TABLE ONLY siresto.pembelian_bahan_baku DROP CONSTRAINT pembelian_bahan_baku_namabahan_fkey;
ALTER TABLE ONLY siresto.pembelian_bahan_baku DROP CONSTRAINT pembelian_bahan_baku_idsupplier_fkey;
ALTER TABLE ONLY siresto.pembelian_bahan_baku DROP CONSTRAINT pembelian_bahan_baku_idkaryawan_fkey;
ALTER TABLE ONLY siresto.menu DROP CONSTRAINT menu_idkategori_fkey;
ALTER TABLE ONLY siresto.menu_harian DROP CONSTRAINT menu_harian_namamenu_fkey;
ALTER TABLE ONLY siresto.menu_harian DROP CONSTRAINT menu_harian_idkoki_fkey;
ALTER TABLE ONLY siresto.koki DROP CONSTRAINT koki_id_fkey;
ALTER TABLE ONLY siresto.bahan_baku_menu DROP CONSTRAINT bahan_baku_menu_namamenu_fkey;
ALTER TABLE ONLY siresto.bahan_baku_menu DROP CONSTRAINT bahan_baku_menu_namabahan_fkey;
SET search_path = simbion, pg_catalog;

ALTER TABLE ONLY simbion.yayasan DROP CONSTRAINT yayasan_nomor_identitas_donatur_fkey;
ALTER TABLE ONLY simbion.syarat_beasiswa DROP CONSTRAINT syarat_beasiswa_kode_beasiswa_fkey;
ALTER TABLE ONLY simbion.skema_beasiswa DROP CONSTRAINT skema_beasiswa_nomor_identitas_donatur_fkey;
ALTER TABLE ONLY simbion.skema_beasiswa_aktif DROP CONSTRAINT skema_beasiswa_aktif_kode_skema_beasiswa_fkey;
ALTER TABLE ONLY simbion.riwayat_akademik DROP CONSTRAINT riwayat_akademik_npm_fkey;
ALTER TABLE ONLY simbion.pengumuman DROP CONSTRAINT pengumuman_username_fkey;
ALTER TABLE ONLY simbion.pendaftaran DROP CONSTRAINT pendaftaran_npm_fkey;
ALTER TABLE ONLY simbion.pendaftaran DROP CONSTRAINT pendaftaran_kode_skema_beasiswa_fkey;
ALTER TABLE ONLY simbion.pembayaran DROP CONSTRAINT pembayaran_npm_fkey;
ALTER TABLE ONLY simbion.mahasiswa DROP CONSTRAINT mahasiswa_username_fkey;
ALTER TABLE ONLY simbion.individual_donor DROP CONSTRAINT individual_donor_nomor_identitas_donatur_fkey;
ALTER TABLE ONLY simbion.donatur DROP CONSTRAINT donatur_username_fkey;
ALTER TABLE ONLY simbion.admin DROP CONSTRAINT admin_username_fkey;
SET search_path = sitikop, pg_catalog;

DROP TRIGGER jumlah_tiket_trigger ON sitikop.pemesanan;
DROP TRIGGER cek_tiket_trigger ON sitikop.pemesanan;
DROP TRIGGER capacity_trigger ON sitikop.seating;
SET search_path = simbion, pg_catalog;

DROP TRIGGER total_pembayaran_trigger ON simbion.pembayaran;
DROP TRIGGER jumlah_pendaftar_trigger ON simbion.pendaftaran;
SET search_path = sitikop, pg_catalog;

DROP INDEX sitikop.tkt_seating_idx;
DROP INDEX sitikop.seat_kursi_idx;
DROP INDEX sitikop.pms_tgl_pesan_idx;
DROP INDEX sitikop.pm_idtgl_idx;
DROP INDEX sitikop.mem_nama_idx;
DROP INDEX sitikop.mem_alamat_idx;
DROP INDEX sitikop.jdw_film_idx;
DROP INDEX sitikop.film_judul_idx;
ALTER TABLE ONLY sitikop.tiket DROP CONSTRAINT tiket_pkey;
ALTER TABLE ONLY sitikop.tiket DROP CONSTRAINT tiket_id_seating_id_jadwal_key;
ALTER TABLE ONLY sitikop.studio DROP CONSTRAINT studio_pkey;
ALTER TABLE ONLY sitikop.seating DROP CONSTRAINT seating_pkey;
ALTER TABLE ONLY sitikop.seating DROP CONSTRAINT seating_no_studio_no_kursi_key;
ALTER TABLE ONLY sitikop.pemesanan DROP CONSTRAINT pemesanan_pkey;
ALTER TABLE ONLY sitikop.member DROP CONSTRAINT member_pkey;
ALTER TABLE ONLY sitikop.jadwal DROP CONSTRAINT jadwal_pkey;
ALTER TABLE ONLY sitikop.film DROP CONSTRAINT film_pkey;
SET search_path = siresto, pg_catalog;

ALTER TABLE ONLY siresto.supplier DROP CONSTRAINT supplier_pkey;
ALTER TABLE ONLY siresto.pembelian_bahan_baku DROP CONSTRAINT pembelian_bahan_baku_pkey;
ALTER TABLE ONLY siresto.menu DROP CONSTRAINT menu_pkey;
ALTER TABLE ONLY siresto.menu_harian DROP CONSTRAINT menu_harian_pkey;
ALTER TABLE ONLY siresto.koki DROP CONSTRAINT koki_pkey;
ALTER TABLE ONLY siresto.kategori DROP CONSTRAINT kategori_pkey;
ALTER TABLE ONLY siresto.karyawan DROP CONSTRAINT karyawan_pkey;
ALTER TABLE ONLY siresto.karyawan DROP CONSTRAINT karyawan_no_ktp_key;
ALTER TABLE ONLY siresto.bahan_baku DROP CONSTRAINT bahan_baku_pkey;
ALTER TABLE ONLY siresto.bahan_baku_menu DROP CONSTRAINT bahan_baku_menu_pkey;
SET search_path = simbion, pg_catalog;

ALTER TABLE ONLY simbion.yayasan DROP CONSTRAINT yayasan_pkey;
ALTER TABLE ONLY simbion.wawancara DROP CONSTRAINT wawancara_pkey;
ALTER TABLE ONLY simbion.wawancara DROP CONSTRAINT wawancara_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key;
ALTER TABLE ONLY simbion.tempat_wawancara DROP CONSTRAINT tempat_wawancara_pkey;
ALTER TABLE ONLY simbion.syarat_beasiswa DROP CONSTRAINT syarat_beasiswa_pkey;
ALTER TABLE ONLY simbion.skema_beasiswa DROP CONSTRAINT skema_beasiswa_pkey;
ALTER TABLE ONLY simbion.skema_beasiswa_aktif DROP CONSTRAINT skema_beasiswa_aktif_pkey;
ALTER TABLE ONLY simbion.riwayat_akademik DROP CONSTRAINT riwayat_akademik_pkey;
ALTER TABLE ONLY simbion.pengumuman DROP CONSTRAINT pengumuman_pkey;
ALTER TABLE ONLY simbion.pengumuman DROP CONSTRAINT pengumuman_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key;
ALTER TABLE ONLY simbion.pengguna DROP CONSTRAINT pengguna_pkey;
ALTER TABLE ONLY simbion.pendaftaran DROP CONSTRAINT pendaftaran_pkey;
ALTER TABLE ONLY simbion.pembayaran DROP CONSTRAINT pembayaran_urutan_kode_skema_beasiswa_no_urut_skema_beasisw_key;
ALTER TABLE ONLY simbion.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY simbion.mahasiswa DROP CONSTRAINT mahasiswa_pkey;
ALTER TABLE ONLY simbion.individual_donor DROP CONSTRAINT individual_donor_pkey;
ALTER TABLE ONLY simbion.donatur DROP CONSTRAINT donatur_pkey;
ALTER TABLE ONLY simbion.admin DROP CONSTRAINT admin_pkey;
SET search_path = sitikop, pg_catalog;

SET search_path = siresto, pg_catalog;

SET search_path = simbion, pg_catalog;

SET search_path = sitikop, pg_catalog;

DROP TABLE sitikop.tiket_dipesan;
DROP TABLE sitikop.tiket;
DROP TABLE sitikop.studio;
DROP TABLE sitikop.seating;
DROP TABLE sitikop.pemesanan;
DROP TABLE sitikop.member;
DROP TABLE sitikop.jumlah_tiket;
DROP TABLE sitikop.jumlah_dipesan;
DROP TABLE sitikop.jadwal;
DROP TABLE sitikop.film;
SET search_path = siresto, pg_catalog;

DROP TABLE siresto.supplier;
DROP TABLE siresto.pembelian_bahan_baku;
DROP TABLE siresto.menu_harian;
DROP TABLE siresto.menu;
DROP TABLE siresto.koki;
DROP TABLE siresto.kategori;
DROP TABLE siresto.karyawan;
DROP TABLE siresto.bahan_baku_menu;
DROP TABLE siresto.bahan_baku;
SET search_path = simbion, pg_catalog;

DROP TABLE simbion.yayasan;
DROP TABLE simbion.wawancara;
DROP TABLE simbion.tempat_wawancara;
DROP TABLE simbion.syarat_beasiswa;
DROP TABLE simbion.skema_beasiswa_aktif;
DROP TABLE simbion.skema_beasiswa;
DROP TABLE simbion.riwayat_akademik;
DROP TABLE simbion.pengumuman;
DROP TABLE simbion.pengguna;
DROP TABLE simbion.pendaftaran;
DROP TABLE simbion.pembayaran;
DROP TABLE simbion.mahasiswa;
DROP TABLE simbion.individual_donor;
DROP TABLE simbion.donatur;
DROP TABLE simbion.admin;
SET search_path = sitikop, pg_catalog;

DROP FUNCTION sitikop.hitung_tiket_dipesan();
DROP FUNCTION sitikop.hitung_tiket(nama_member character varying);
DROP FUNCTION sitikop.hitung_jumlah_tiket();
DROP FUNCTION sitikop.cek_pemesanan();
DROP FUNCTION sitikop.capacity_constraint();
SET search_path = simbion, pg_catalog;

DROP FUNCTION simbion.total_pembayaran_beasiswa();
DROP FUNCTION simbion.jumlah_pendaftar_beasiswa();
DROP EXTENSION plpgsql;
DROP SCHEMA sitikop;
DROP SCHEMA siresto;
DROP SCHEMA simbion;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: simbion; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA simbion;


ALTER SCHEMA simbion OWNER TO postgres;

--
-- Name: siresto; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA siresto;


ALTER SCHEMA siresto OWNER TO postgres;

--
-- Name: sitikop; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sitikop;


ALTER SCHEMA sitikop OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = simbion, pg_catalog;

--
-- Name: jumlah_pendaftar_beasiswa(); Type: FUNCTION; Schema: simbion; Owner: postgres
--

CREATE FUNCTION jumlah_pendaftar_beasiswa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
ROW RECORD;
BEGIN
FOR ROW IN
SELECT sba.kode_skema_beasiswa AS kode, sba.no_urut AS nomor, COUNT(P.*) AS jumlah_pendaftar
FROM SKEMA_BEASISWA_AKTIF sba
LEFT JOIN PENDAFTARAN P
ON SBA.kode_skema_beasiswa = P.kode_skema_beasiswa
AND P.no_urut = SBA.no_urut
GROUP BY sba.kode_skema_beasiswa, sba.no_urut
LOOP
UPDATE skema_beasiswa_aktif SET jumlah_pendaftar = row.jumlah_pendaftar
WHERE kode_skema_beasiswa = row.kode AND no_urut = row.nomor;
END LOOP;
RETURN NEW;
END
$$;


ALTER FUNCTION simbion.jumlah_pendaftar_beasiswa() OWNER TO postgres;

--
-- Name: total_pembayaran_beasiswa(); Type: FUNCTION; Schema: simbion; Owner: postgres
--

CREATE FUNCTION total_pembayaran_beasiswa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
ROW RECORD;
BEGIN
FOR ROW IN
SELECT sba.kode_skema_beasiswa AS kode, sba.no_urut AS nomor, sum(P.nominal) AS total_pembayaran
FROM SKEMA_BEASISWA_AKTIF sba
LEFT JOIN PEMBAYARAN P
ON SBA.kode_skema_beasiswa = P.kode_skema_beasiswa
AND P.no_urut_skema_beasiswa_aktif = SBA.no_urut
GROUP BY sba.kode_skema_beasiswa, sba.no_urut
LOOP
UPDATE skema_beasiswa_aktif SET total_pembayaran = row.total_pembayaran
WHERE kode_skema_beasiswa = row.kode AND no_urut = row.nomor;
END LOOP;
RETURN NEW;
END
$$;


ALTER FUNCTION simbion.total_pembayaran_beasiswa() OWNER TO postgres;

SET search_path = sitikop, pg_catalog;

--
-- Name: capacity_constraint(); Type: FUNCTION; Schema: sitikop; Owner: postgres
--

CREATE FUNCTION capacity_constraint() RETURNS trigger
    LANGUAGE plpgsql
    AS $$  
DECLARE 
kapasitas_studio INTEGER; 
jumlah_seating_studio INTEGER;
BEGIN    
SELECT kapasitas INTO kapasitas_studio    
FROM STUDIO S    
WHERE S.No_studio = NEW.no_studio; 
SELECT count(id_seating) INTO jumlah_seating_studio 
FROM SEATING SE 
WHERE SE.No_studio = NEW.no_studio;         
IF (TG_OP = 'INSERT') THEN
IF(kapasitas_studio == jumlah_seating_studio) THEN           
RAISE EXCEPTION 'Error : Kapasitas Studio Sudah Penuh';         
END IF;              
RETURN NEW;          
END IF;      
END;  
$$;


ALTER FUNCTION sitikop.capacity_constraint() OWNER TO postgres;

--
-- Name: cek_pemesanan(); Type: FUNCTION; Schema: sitikop; Owner: postgres
--

CREATE FUNCTION cek_pemesanan() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
jumlah_pesan_tiket INTEGER;
BEGIN
SELECT count(P.id_tiket) INTO jumlah_pesan_tiket
FROM PEMESANAN P
WHERE P.id_tiket = NEW.id_tiket;
IF (TG_OP = 'INSERT') THEN
IF (jumlah_pesan_tiket > 0) THEN
RAISE EXCEPTION 'Error: Tiket sudah terjual.';
END IF;
RETURN NEW;
END IF;
END;
$$;


ALTER FUNCTION sitikop.cek_pemesanan() OWNER TO postgres;

--
-- Name: hitung_jumlah_tiket(); Type: FUNCTION; Schema: sitikop; Owner: postgres
--

CREATE FUNCTION hitung_jumlah_tiket() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
ROW RECORD;
BEGIN
FOR ROW IN
SELECT M.email, COUNT(P.email_member) AS jumlah_pesan
FROM MEMBER M
LEFT JOIN PEMESANAN P
ON M.email = P.email_member
GROUP BY M.email
LOOP
UPDATE MEMBER SET jumlah_pesan_tiket =
row.jumlah_pesan
WHERE email = row.email;
END LOOP;
RETURN NEW;
END
$$;


ALTER FUNCTION sitikop.hitung_jumlah_tiket() OWNER TO postgres;

--
-- Name: hitung_tiket(character varying); Type: FUNCTION; Schema: sitikop; Owner: postgres
--

CREATE FUNCTION hitung_tiket(nama_member character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
jumlah_tiket INTEGER;
BEGIN
SELECT count(p.*) INTO jumlah_tiket
FROM MEMBER m, PEMESANAN p 
WHERE p.email_member = m.email
AND m.nama = nama_member;

UPDATE MEMBER m SET jumlah_pesan_tiket = jumlah_tiket 
WHERE m.nama = nama_member;
RETURN jumlah_tiket;
END;
$$;


ALTER FUNCTION sitikop.hitung_tiket(nama_member character varying) OWNER TO postgres;

--
-- Name: hitung_tiket_dipesan(); Type: FUNCTION; Schema: sitikop; Owner: postgres
--

CREATE FUNCTION hitung_tiket_dipesan() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
row RECORD;
BEGIN
FOR row IN
SELECT J.Id_jadwal as id_jadwal, COUNT(P.*) AS jumlah_dipesan
FROM JADWAL J, TIKET T, PEMESANAN P
WHERE T.Id_jadwal = J.Id_jadwal AND P.Id_tiket =T.Id_tiket
GROUP BY J.id_jadwal
LOOP
UPDATE JADWAL SET jumlah_tiket_dipesan = row.jumlah_dipesan
WHERE Id_jadwal = row.Id_jadwal;  
END LOOP;
END;
$$;


ALTER FUNCTION sitikop.hitung_tiket_dipesan() OWNER TO postgres;

SET search_path = simbion, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: admin; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE admin (
    username character varying(50) NOT NULL
);


ALTER TABLE simbion.admin OWNER TO postgres;

--
-- Name: donatur; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE donatur (
    nomor_identitas character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    npwp character(20) NOT NULL,
    no_telp character varying(20),
    alamat character varying(100) NOT NULL,
    username character varying(50) NOT NULL
);


ALTER TABLE simbion.donatur OWNER TO postgres;

--
-- Name: individual_donor; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE individual_donor (
    nik character(16) NOT NULL,
    nomor_identitas_donatur character varying(20) NOT NULL
);


ALTER TABLE simbion.individual_donor OWNER TO postgres;

--
-- Name: mahasiswa; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE mahasiswa (
    npm character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    no_telp character varying(20),
    alamat_tinggal character varying(50) NOT NULL,
    alamat_domisili character varying(50) NOT NULL,
    nama_bank character varying(50) NOT NULL,
    no_rekening character varying(20) NOT NULL,
    nama_pemilik character varying(50) NOT NULL,
    username character varying(50) NOT NULL
);


ALTER TABLE simbion.mahasiswa OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE pembayaran (
    urutan integer NOT NULL,
    kode_skema_beasiswa integer NOT NULL,
    no_urut_skema_beasiswa_aktif integer NOT NULL,
    npm character varying(20) NOT NULL,
    keterangan character varying(20) NOT NULL,
    tgl_bayar date NOT NULL,
    nominal integer NOT NULL
);


ALTER TABLE simbion.pembayaran OWNER TO postgres;

--
-- Name: pendaftaran; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE pendaftaran (
    no_urut integer NOT NULL,
    kode_skema_beasiswa integer NOT NULL,
    npm character varying(20) NOT NULL,
    waktu_daftar timestamp without time zone NOT NULL,
    status_daftar character varying(20) NOT NULL,
    status_terima character varying(20) NOT NULL
);


ALTER TABLE simbion.pendaftaran OWNER TO postgres;

--
-- Name: pengguna; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE pengguna (
    username character varying(20) NOT NULL,
    password character varying(20) NOT NULL,
    role character varying(20)
);


ALTER TABLE simbion.pengguna OWNER TO postgres;

--
-- Name: pengumuman; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE pengumuman (
    tanggal date NOT NULL,
    no_urut_skema_beasiswa_aktif integer NOT NULL,
    kode_skema_beasiswa integer NOT NULL,
    username character varying(20) NOT NULL,
    judul character varying(100) NOT NULL,
    isi character varying(255) NOT NULL
);


ALTER TABLE simbion.pengumuman OWNER TO postgres;

--
-- Name: riwayat_akademik; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE riwayat_akademik (
    no_urut integer NOT NULL,
    npm character varying(20) NOT NULL,
    semester character(1) NOT NULL,
    tahun_ajaran character(9) NOT NULL,
    jumlah_sks integer NOT NULL,
    ips double precision NOT NULL,
    lampiran character varying(200) NOT NULL
);


ALTER TABLE simbion.riwayat_akademik OWNER TO postgres;

--
-- Name: skema_beasiswa; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE skema_beasiswa (
    kode integer NOT NULL,
    nama character varying(50) NOT NULL,
    jenis character varying(50) NOT NULL,
    deskripsi character varying(100) NOT NULL,
    nomor_identitas_donatur character(16) NOT NULL
);


ALTER TABLE simbion.skema_beasiswa OWNER TO postgres;

--
-- Name: skema_beasiswa_aktif; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE skema_beasiswa_aktif (
    kode_skema_beasiswa integer NOT NULL,
    no_urut integer NOT NULL,
    tgl_mulai_pendaftaran date NOT NULL,
    tgl_tutup_pendaftaran date NOT NULL,
    periode_penerimaan character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    jumlah_pendaftar integer NOT NULL,
    total_pendaftar integer NOT NULL,
    total_pembayaran integer NOT NULL
);


ALTER TABLE simbion.skema_beasiswa_aktif OWNER TO postgres;

--
-- Name: syarat_beasiswa; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE syarat_beasiswa (
    kode_beasiswa integer NOT NULL,
    syarat character varying(50) NOT NULL
);


ALTER TABLE simbion.syarat_beasiswa OWNER TO postgres;

--
-- Name: tempat_wawancara; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE tempat_wawancara (
    kode integer NOT NULL,
    nama character varying(20) NOT NULL,
    lokasi character varying(50) NOT NULL
);


ALTER TABLE simbion.tempat_wawancara OWNER TO postgres;

--
-- Name: wawancara; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE wawancara (
    no_urut_skema_beasiswa_aktif integer NOT NULL,
    kode_skema_beasiswa integer NOT NULL,
    jadwal character varying(20) NOT NULL,
    kode_tempat_wawancara integer NOT NULL
);


ALTER TABLE simbion.wawancara OWNER TO postgres;

--
-- Name: yayasan; Type: TABLE; Schema: simbion; Owner: postgres; Tablespace: 
--

CREATE TABLE yayasan (
    no_sk_yayasan character varying(20) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    no_telp_cp character varying(20),
    nomor_identitas_donatur character(16) NOT NULL
);


ALTER TABLE simbion.yayasan OWNER TO postgres;

SET search_path = siresto, pg_catalog;

--
-- Name: bahan_baku; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE bahan_baku (
    nama character varying(50) NOT NULL,
    stok smallint NOT NULL,
    satuan character varying(10) NOT NULL
);


ALTER TABLE siresto.bahan_baku OWNER TO postgres;

--
-- Name: bahan_baku_menu; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE bahan_baku_menu (
    namamenu character varying(50) NOT NULL,
    namabahan character varying(50) NOT NULL,
    jumlah smallint NOT NULL,
    satuan character varying(10) NOT NULL
);


ALTER TABLE siresto.bahan_baku_menu OWNER TO postgres;

--
-- Name: karyawan; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE karyawan (
    id character(5) NOT NULL,
    nama character varying(50) NOT NULL,
    tgllahir date,
    no_ktp character(16) NOT NULL,
    posisi character varying(18) NOT NULL
);


ALTER TABLE siresto.karyawan OWNER TO postgres;

--
-- Name: kategori; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE kategori (
    id character(5) NOT NULL,
    nama character varying(50) NOT NULL
);


ALTER TABLE siresto.kategori OWNER TO postgres;

--
-- Name: koki; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE koki (
    id character(5) NOT NULL,
    sertifikasi character varying(50) NOT NULL
);


ALTER TABLE siresto.koki OWNER TO postgres;

--
-- Name: menu; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE menu (
    nama character varying(50) NOT NULL,
    harga integer NOT NULL,
    idkategori character(5) NOT NULL
);


ALTER TABLE siresto.menu OWNER TO postgres;

--
-- Name: menu_harian; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE menu_harian (
    namamenu character varying(50) NOT NULL,
    tanggal date NOT NULL,
    idkoki character(5) NOT NULL,
    jumlah smallint NOT NULL
);


ALTER TABLE siresto.menu_harian OWNER TO postgres;

--
-- Name: pembelian_bahan_baku; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE pembelian_bahan_baku (
    nota character varying(10) NOT NULL,
    namabahan character varying(50) NOT NULL,
    jumlah smallint NOT NULL,
    satuan character varying(10) NOT NULL,
    hargasatuan integer NOT NULL,
    waktu date NOT NULL,
    idsupplier character(5) NOT NULL,
    idkaryawan character(5) NOT NULL
);


ALTER TABLE siresto.pembelian_bahan_baku OWNER TO postgres;

--
-- Name: supplier; Type: TABLE; Schema: siresto; Owner: postgres; Tablespace: 
--

CREATE TABLE supplier (
    id character(5) NOT NULL,
    nama character varying(50) NOT NULL,
    telepon character varying(15) NOT NULL,
    email text
);


ALTER TABLE siresto.supplier OWNER TO postgres;

SET search_path = sitikop, pg_catalog;

--
-- Name: film; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE film (
    id_film character(5) NOT NULL,
    judul character varying(100) NOT NULL,
    kategori character varying(100) NOT NULL
);


ALTER TABLE sitikop.film OWNER TO postgres;

--
-- Name: jadwal; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE jadwal (
    id_jadwal character(5) NOT NULL,
    tanggal date NOT NULL,
    waktu_mulai time without time zone NOT NULL,
    waktu_selesai time without time zone NOT NULL,
    id_film character(5) NOT NULL,
    jumlah_tiket_dipesan integer DEFAULT 0
);


ALTER TABLE sitikop.jadwal OWNER TO postgres;

--
-- Name: jumlah_dipesan; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE jumlah_dipesan (
    count bigint
);


ALTER TABLE sitikop.jumlah_dipesan OWNER TO postgres;

--
-- Name: jumlah_tiket; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE jumlah_tiket (
    count bigint
);


ALTER TABLE sitikop.jumlah_tiket OWNER TO postgres;

--
-- Name: member; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE member (
    email character varying(30) NOT NULL,
    nama character varying(30) NOT NULL,
    jenis_kelamin character(1) NOT NULL,
    alamat character varying(100) NOT NULL,
    no_hp character varying(12),
    jumlah_pesan_tiket integer DEFAULT 0
);


ALTER TABLE sitikop.member OWNER TO postgres;

--
-- Name: pemesanan; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE pemesanan (
    email_member character varying(30) NOT NULL,
    id_tiket character(5) NOT NULL,
    tgl_pesan date NOT NULL
);


ALTER TABLE sitikop.pemesanan OWNER TO postgres;

--
-- Name: seating; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE seating (
    id_seating character(5) NOT NULL,
    no_studio character(5) NOT NULL,
    no_kursi character(3) NOT NULL
);


ALTER TABLE sitikop.seating OWNER TO postgres;

--
-- Name: studio; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE studio (
    no_studio character(5) NOT NULL,
    kapasitas integer NOT NULL,
    type character varying(10) NOT NULL
);


ALTER TABLE sitikop.studio OWNER TO postgres;

--
-- Name: tiket; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE tiket (
    id_tiket character(10) NOT NULL,
    harga integer NOT NULL,
    id_seating character(5) NOT NULL,
    id_jadwal character(5) NOT NULL
);


ALTER TABLE sitikop.tiket OWNER TO postgres;

--
-- Name: tiket_dipesan; Type: TABLE; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE TABLE tiket_dipesan (
    count bigint
);


ALTER TABLE sitikop.tiket_dipesan OWNER TO postgres;

SET search_path = simbion, pg_catalog;

--
-- Data for Name: admin; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY admin (username) FROM stdin;
\.
COPY admin (username) FROM '$$PATH$$/2209.dat';

--
-- Data for Name: donatur; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY donatur (nomor_identitas, email, nama, npwp, no_telp, alamat, username) FROM stdin;
\.
COPY donatur (nomor_identitas, email, nama, npwp, no_telp, alamat, username) FROM '$$PATH$$/2208.dat';

--
-- Data for Name: individual_donor; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY individual_donor (nik, nomor_identitas_donatur) FROM stdin;
\.
COPY individual_donor (nik, nomor_identitas_donatur) FROM '$$PATH$$/2210.dat';

--
-- Data for Name: mahasiswa; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY mahasiswa (npm, email, nama, no_telp, alamat_tinggal, alamat_domisili, nama_bank, no_rekening, nama_pemilik, username) FROM stdin;
\.
COPY mahasiswa (npm, email, nama, no_telp, alamat_tinggal, alamat_domisili, nama_bank, no_rekening, nama_pemilik, username) FROM '$$PATH$$/2211.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY pembayaran (urutan, kode_skema_beasiswa, no_urut_skema_beasiswa_aktif, npm, keterangan, tgl_bayar, nominal) FROM stdin;
\.
COPY pembayaran (urutan, kode_skema_beasiswa, no_urut_skema_beasiswa_aktif, npm, keterangan, tgl_bayar, nominal) FROM '$$PATH$$/2218.dat';

--
-- Data for Name: pendaftaran; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY pendaftaran (no_urut, kode_skema_beasiswa, npm, waktu_daftar, status_daftar, status_terima) FROM stdin;
\.
COPY pendaftaran (no_urut, kode_skema_beasiswa, npm, waktu_daftar, status_daftar, status_terima) FROM '$$PATH$$/2217.dat';

--
-- Data for Name: pengguna; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY pengguna (username, password, role) FROM stdin;
\.
COPY pengguna (username, password, role) FROM '$$PATH$$/2207.dat';

--
-- Data for Name: pengumuman; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY pengumuman (tanggal, no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, username, judul, isi) FROM stdin;
\.
COPY pengumuman (tanggal, no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, username, judul, isi) FROM '$$PATH$$/2221.dat';

--
-- Data for Name: riwayat_akademik; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY riwayat_akademik (no_urut, npm, semester, tahun_ajaran, jumlah_sks, ips, lampiran) FROM stdin;
\.
COPY riwayat_akademik (no_urut, npm, semester, tahun_ajaran, jumlah_sks, ips, lampiran) FROM '$$PATH$$/2213.dat';

--
-- Data for Name: skema_beasiswa; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY skema_beasiswa (kode, nama, jenis, deskripsi, nomor_identitas_donatur) FROM stdin;
\.
COPY skema_beasiswa (kode, nama, jenis, deskripsi, nomor_identitas_donatur) FROM '$$PATH$$/2214.dat';

--
-- Data for Name: skema_beasiswa_aktif; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY skema_beasiswa_aktif (kode_skema_beasiswa, no_urut, tgl_mulai_pendaftaran, tgl_tutup_pendaftaran, periode_penerimaan, status, jumlah_pendaftar, total_pendaftar, total_pembayaran) FROM stdin;
\.
COPY skema_beasiswa_aktif (kode_skema_beasiswa, no_urut, tgl_mulai_pendaftaran, tgl_tutup_pendaftaran, periode_penerimaan, status, jumlah_pendaftar, total_pendaftar, total_pembayaran) FROM '$$PATH$$/2216.dat';

--
-- Data for Name: syarat_beasiswa; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY syarat_beasiswa (kode_beasiswa, syarat) FROM stdin;
\.
COPY syarat_beasiswa (kode_beasiswa, syarat) FROM '$$PATH$$/2215.dat';

--
-- Data for Name: tempat_wawancara; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY tempat_wawancara (kode, nama, lokasi) FROM stdin;
\.
COPY tempat_wawancara (kode, nama, lokasi) FROM '$$PATH$$/2219.dat';

--
-- Data for Name: wawancara; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY wawancara (no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, jadwal, kode_tempat_wawancara) FROM stdin;
\.
COPY wawancara (no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, jadwal, kode_tempat_wawancara) FROM '$$PATH$$/2220.dat';

--
-- Data for Name: yayasan; Type: TABLE DATA; Schema: simbion; Owner: postgres
--

COPY yayasan (no_sk_yayasan, email, nama, no_telp_cp, nomor_identitas_donatur) FROM stdin;
\.
COPY yayasan (no_sk_yayasan, email, nama, no_telp_cp, nomor_identitas_donatur) FROM '$$PATH$$/2212.dat';

SET search_path = siresto, pg_catalog;

--
-- Data for Name: bahan_baku; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY bahan_baku (nama, stok, satuan) FROM stdin;
\.
COPY bahan_baku (nama, stok, satuan) FROM '$$PATH$$/2198.dat';

--
-- Data for Name: bahan_baku_menu; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY bahan_baku_menu (namamenu, namabahan, jumlah, satuan) FROM stdin;
\.
COPY bahan_baku_menu (namamenu, namabahan, jumlah, satuan) FROM '$$PATH$$/2202.dat';

--
-- Data for Name: karyawan; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY karyawan (id, nama, tgllahir, no_ktp, posisi) FROM stdin;
\.
COPY karyawan (id, nama, tgllahir, no_ktp, posisi) FROM '$$PATH$$/2195.dat';

--
-- Data for Name: kategori; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY kategori (id, nama) FROM stdin;
\.
COPY kategori (id, nama) FROM '$$PATH$$/2197.dat';

--
-- Data for Name: koki; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY koki (id, sertifikasi) FROM stdin;
\.
COPY koki (id, sertifikasi) FROM '$$PATH$$/2199.dat';

--
-- Data for Name: menu; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY menu (nama, harga, idkategori) FROM stdin;
\.
COPY menu (nama, harga, idkategori) FROM '$$PATH$$/2200.dat';

--
-- Data for Name: menu_harian; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY menu_harian (namamenu, tanggal, idkoki, jumlah) FROM stdin;
\.
COPY menu_harian (namamenu, tanggal, idkoki, jumlah) FROM '$$PATH$$/2201.dat';

--
-- Data for Name: pembelian_bahan_baku; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY pembelian_bahan_baku (nota, namabahan, jumlah, satuan, hargasatuan, waktu, idsupplier, idkaryawan) FROM stdin;
\.
COPY pembelian_bahan_baku (nota, namabahan, jumlah, satuan, hargasatuan, waktu, idsupplier, idkaryawan) FROM '$$PATH$$/2203.dat';

--
-- Data for Name: supplier; Type: TABLE DATA; Schema: siresto; Owner: postgres
--

COPY supplier (id, nama, telepon, email) FROM stdin;
\.
COPY supplier (id, nama, telepon, email) FROM '$$PATH$$/2196.dat';

SET search_path = sitikop, pg_catalog;

--
-- Data for Name: film; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY film (id_film, judul, kategori) FROM stdin;
\.
COPY film (id_film, judul, kategori) FROM '$$PATH$$/2188.dat';

--
-- Data for Name: jadwal; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY jadwal (id_jadwal, tanggal, waktu_mulai, waktu_selesai, id_film, jumlah_tiket_dipesan) FROM stdin;
\.
COPY jadwal (id_jadwal, tanggal, waktu_mulai, waktu_selesai, id_film, jumlah_tiket_dipesan) FROM '$$PATH$$/2191.dat';

--
-- Data for Name: jumlah_dipesan; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY jumlah_dipesan (count) FROM stdin;
\.
COPY jumlah_dipesan (count) FROM '$$PATH$$/2204.dat';

--
-- Data for Name: jumlah_tiket; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY jumlah_tiket (count) FROM stdin;
\.
COPY jumlah_tiket (count) FROM '$$PATH$$/2205.dat';

--
-- Data for Name: member; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY member (email, nama, jenis_kelamin, alamat, no_hp, jumlah_pesan_tiket) FROM stdin;
\.
COPY member (email, nama, jenis_kelamin, alamat, no_hp, jumlah_pesan_tiket) FROM '$$PATH$$/2193.dat';

--
-- Data for Name: pemesanan; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY pemesanan (email_member, id_tiket, tgl_pesan) FROM stdin;
\.
COPY pemesanan (email_member, id_tiket, tgl_pesan) FROM '$$PATH$$/2194.dat';

--
-- Data for Name: seating; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY seating (id_seating, no_studio, no_kursi) FROM stdin;
\.
COPY seating (id_seating, no_studio, no_kursi) FROM '$$PATH$$/2190.dat';

--
-- Data for Name: studio; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY studio (no_studio, kapasitas, type) FROM stdin;
\.
COPY studio (no_studio, kapasitas, type) FROM '$$PATH$$/2189.dat';

--
-- Data for Name: tiket; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY tiket (id_tiket, harga, id_seating, id_jadwal) FROM stdin;
\.
COPY tiket (id_tiket, harga, id_seating, id_jadwal) FROM '$$PATH$$/2192.dat';

--
-- Data for Name: tiket_dipesan; Type: TABLE DATA; Schema: sitikop; Owner: postgres
--

COPY tiket_dipesan (count) FROM stdin;
\.
COPY tiket_dipesan (count) FROM '$$PATH$$/2206.dat';

SET search_path = simbion, pg_catalog;

--
-- Name: admin_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (username);


--
-- Name: donatur_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY donatur
    ADD CONSTRAINT donatur_pkey PRIMARY KEY (nomor_identitas);


--
-- Name: individual_donor_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY individual_donor
    ADD CONSTRAINT individual_donor_pkey PRIMARY KEY (nik);


--
-- Name: mahasiswa_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY mahasiswa
    ADD CONSTRAINT mahasiswa_pkey PRIMARY KEY (npm);


--
-- Name: pembayaran_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (urutan, kode_skema_beasiswa, no_urut_skema_beasiswa_aktif, npm);


--
-- Name: pembayaran_urutan_kode_skema_beasiswa_no_urut_skema_beasisw_key; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_urutan_kode_skema_beasiswa_no_urut_skema_beasisw_key UNIQUE (urutan, kode_skema_beasiswa, no_urut_skema_beasiswa_aktif);


--
-- Name: pendaftaran_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_pkey PRIMARY KEY (no_urut, kode_skema_beasiswa, npm);


--
-- Name: pengguna_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pengguna
    ADD CONSTRAINT pengguna_pkey PRIMARY KEY (username);


--
-- Name: pengumuman_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pengumuman
    ADD CONSTRAINT pengumuman_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key UNIQUE (no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, username);


--
-- Name: pengumuman_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pengumuman
    ADD CONSTRAINT pengumuman_pkey PRIMARY KEY (tanggal, no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, username);


--
-- Name: riwayat_akademik_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY riwayat_akademik
    ADD CONSTRAINT riwayat_akademik_pkey PRIMARY KEY (no_urut, npm);


--
-- Name: skema_beasiswa_aktif_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY skema_beasiswa_aktif
    ADD CONSTRAINT skema_beasiswa_aktif_pkey PRIMARY KEY (kode_skema_beasiswa, no_urut);


--
-- Name: skema_beasiswa_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY skema_beasiswa
    ADD CONSTRAINT skema_beasiswa_pkey PRIMARY KEY (kode);


--
-- Name: syarat_beasiswa_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY syarat_beasiswa
    ADD CONSTRAINT syarat_beasiswa_pkey PRIMARY KEY (kode_beasiswa, syarat);


--
-- Name: tempat_wawancara_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tempat_wawancara
    ADD CONSTRAINT tempat_wawancara_pkey PRIMARY KEY (kode);


--
-- Name: wawancara_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY wawancara
    ADD CONSTRAINT wawancara_no_urut_skema_beasiswa_aktif_kode_skema_beasiswa_key UNIQUE (no_urut_skema_beasiswa_aktif, kode_skema_beasiswa);


--
-- Name: wawancara_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY wawancara
    ADD CONSTRAINT wawancara_pkey PRIMARY KEY (no_urut_skema_beasiswa_aktif, kode_skema_beasiswa, jadwal);


--
-- Name: yayasan_pkey; Type: CONSTRAINT; Schema: simbion; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY yayasan
    ADD CONSTRAINT yayasan_pkey PRIMARY KEY (no_sk_yayasan);


SET search_path = siresto, pg_catalog;

--
-- Name: bahan_baku_menu_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY bahan_baku_menu
    ADD CONSTRAINT bahan_baku_menu_pkey PRIMARY KEY (namamenu, namabahan);


--
-- Name: bahan_baku_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY bahan_baku
    ADD CONSTRAINT bahan_baku_pkey PRIMARY KEY (nama);


--
-- Name: karyawan_no_ktp_key; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY karyawan
    ADD CONSTRAINT karyawan_no_ktp_key UNIQUE (no_ktp);


--
-- Name: karyawan_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY karyawan
    ADD CONSTRAINT karyawan_pkey PRIMARY KEY (id);


--
-- Name: kategori_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY kategori
    ADD CONSTRAINT kategori_pkey PRIMARY KEY (id);


--
-- Name: koki_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY koki
    ADD CONSTRAINT koki_pkey PRIMARY KEY (id);


--
-- Name: menu_harian_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menu_harian
    ADD CONSTRAINT menu_harian_pkey PRIMARY KEY (namamenu, tanggal, idkoki);


--
-- Name: menu_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT menu_pkey PRIMARY KEY (nama);


--
-- Name: pembelian_bahan_baku_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pembelian_bahan_baku
    ADD CONSTRAINT pembelian_bahan_baku_pkey PRIMARY KEY (nota);


--
-- Name: supplier_pkey; Type: CONSTRAINT; Schema: siresto; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (id);


SET search_path = sitikop, pg_catalog;

--
-- Name: film_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY film
    ADD CONSTRAINT film_pkey PRIMARY KEY (id_film);


--
-- Name: jadwal_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY jadwal
    ADD CONSTRAINT jadwal_pkey PRIMARY KEY (id_jadwal);


--
-- Name: member_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY member
    ADD CONSTRAINT member_pkey PRIMARY KEY (email);


--
-- Name: pemesanan_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pemesanan
    ADD CONSTRAINT pemesanan_pkey PRIMARY KEY (email_member, id_tiket);


--
-- Name: seating_no_studio_no_kursi_key; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY seating
    ADD CONSTRAINT seating_no_studio_no_kursi_key UNIQUE (no_studio, no_kursi);


--
-- Name: seating_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY seating
    ADD CONSTRAINT seating_pkey PRIMARY KEY (id_seating);


--
-- Name: studio_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY studio
    ADD CONSTRAINT studio_pkey PRIMARY KEY (no_studio);


--
-- Name: tiket_id_seating_id_jadwal_key; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tiket
    ADD CONSTRAINT tiket_id_seating_id_jadwal_key UNIQUE (id_seating, id_jadwal);


--
-- Name: tiket_pkey; Type: CONSTRAINT; Schema: sitikop; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tiket
    ADD CONSTRAINT tiket_pkey PRIMARY KEY (id_tiket);


--
-- Name: film_judul_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX film_judul_idx ON film USING btree (judul);


--
-- Name: jdw_film_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX jdw_film_idx ON jadwal USING btree (id_film);


--
-- Name: mem_alamat_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX mem_alamat_idx ON member USING btree (alamat);


--
-- Name: mem_nama_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX mem_nama_idx ON member USING btree (nama);


--
-- Name: pm_idtgl_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX pm_idtgl_idx ON pemesanan USING btree (id_tiket, tgl_pesan DESC);


--
-- Name: pms_tgl_pesan_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX pms_tgl_pesan_idx ON pemesanan USING btree (tgl_pesan);


--
-- Name: seat_kursi_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX seat_kursi_idx ON seating USING btree (no_kursi);


--
-- Name: tkt_seating_idx; Type: INDEX; Schema: sitikop; Owner: postgres; Tablespace: 
--

CREATE INDEX tkt_seating_idx ON tiket USING btree (id_seating);


SET search_path = simbion, pg_catalog;

--
-- Name: jumlah_pendaftar_trigger; Type: TRIGGER; Schema: simbion; Owner: postgres
--

CREATE TRIGGER jumlah_pendaftar_trigger AFTER INSERT OR DELETE OR UPDATE ON pendaftaran FOR EACH ROW EXECUTE PROCEDURE jumlah_pendaftar_beasiswa();


--
-- Name: total_pembayaran_trigger; Type: TRIGGER; Schema: simbion; Owner: postgres
--

CREATE TRIGGER total_pembayaran_trigger AFTER INSERT OR DELETE OR UPDATE ON pembayaran FOR EACH ROW EXECUTE PROCEDURE total_pembayaran_beasiswa();


SET search_path = sitikop, pg_catalog;

--
-- Name: capacity_trigger; Type: TRIGGER; Schema: sitikop; Owner: postgres
--

CREATE TRIGGER capacity_trigger AFTER INSERT ON seating FOR EACH ROW EXECUTE PROCEDURE capacity_constraint();


--
-- Name: cek_tiket_trigger; Type: TRIGGER; Schema: sitikop; Owner: postgres
--

CREATE TRIGGER cek_tiket_trigger AFTER INSERT ON pemesanan FOR EACH ROW EXECUTE PROCEDURE cek_pemesanan();


--
-- Name: jumlah_tiket_trigger; Type: TRIGGER; Schema: sitikop; Owner: postgres
--

CREATE TRIGGER jumlah_tiket_trigger AFTER INSERT OR DELETE OR UPDATE ON pemesanan FOR EACH ROW EXECUTE PROCEDURE hitung_jumlah_tiket();


SET search_path = simbion, pg_catalog;

--
-- Name: admin_username_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_username_fkey FOREIGN KEY (username) REFERENCES pengguna(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: donatur_username_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY donatur
    ADD CONSTRAINT donatur_username_fkey FOREIGN KEY (username) REFERENCES pengguna(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: individual_donor_nomor_identitas_donatur_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY individual_donor
    ADD CONSTRAINT individual_donor_nomor_identitas_donatur_fkey FOREIGN KEY (nomor_identitas_donatur) REFERENCES donatur(nomor_identitas) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mahasiswa_username_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY mahasiswa
    ADD CONSTRAINT mahasiswa_username_fkey FOREIGN KEY (username) REFERENCES pengguna(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pembayaran_npm_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_npm_fkey FOREIGN KEY (npm) REFERENCES mahasiswa(npm) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_kode_skema_beasiswa_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_kode_skema_beasiswa_fkey FOREIGN KEY (kode_skema_beasiswa) REFERENCES skema_beasiswa(kode) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_npm_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_npm_fkey FOREIGN KEY (npm) REFERENCES mahasiswa(npm) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pengumuman_username_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY pengumuman
    ADD CONSTRAINT pengumuman_username_fkey FOREIGN KEY (username) REFERENCES pengguna(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: riwayat_akademik_npm_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY riwayat_akademik
    ADD CONSTRAINT riwayat_akademik_npm_fkey FOREIGN KEY (npm) REFERENCES mahasiswa(npm) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: skema_beasiswa_aktif_kode_skema_beasiswa_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY skema_beasiswa_aktif
    ADD CONSTRAINT skema_beasiswa_aktif_kode_skema_beasiswa_fkey FOREIGN KEY (kode_skema_beasiswa) REFERENCES skema_beasiswa(kode) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: skema_beasiswa_nomor_identitas_donatur_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY skema_beasiswa
    ADD CONSTRAINT skema_beasiswa_nomor_identitas_donatur_fkey FOREIGN KEY (nomor_identitas_donatur) REFERENCES donatur(nomor_identitas) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: syarat_beasiswa_kode_beasiswa_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY syarat_beasiswa
    ADD CONSTRAINT syarat_beasiswa_kode_beasiswa_fkey FOREIGN KEY (kode_beasiswa) REFERENCES skema_beasiswa(kode) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: yayasan_nomor_identitas_donatur_fkey; Type: FK CONSTRAINT; Schema: simbion; Owner: postgres
--

ALTER TABLE ONLY yayasan
    ADD CONSTRAINT yayasan_nomor_identitas_donatur_fkey FOREIGN KEY (nomor_identitas_donatur) REFERENCES donatur(nomor_identitas) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = siresto, pg_catalog;

--
-- Name: bahan_baku_menu_namabahan_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY bahan_baku_menu
    ADD CONSTRAINT bahan_baku_menu_namabahan_fkey FOREIGN KEY (namabahan) REFERENCES bahan_baku(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bahan_baku_menu_namamenu_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY bahan_baku_menu
    ADD CONSTRAINT bahan_baku_menu_namamenu_fkey FOREIGN KEY (namamenu) REFERENCES menu(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: koki_id_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY koki
    ADD CONSTRAINT koki_id_fkey FOREIGN KEY (id) REFERENCES karyawan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menu_harian_idkoki_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY menu_harian
    ADD CONSTRAINT menu_harian_idkoki_fkey FOREIGN KEY (idkoki) REFERENCES koki(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menu_harian_namamenu_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY menu_harian
    ADD CONSTRAINT menu_harian_namamenu_fkey FOREIGN KEY (namamenu) REFERENCES menu(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: menu_idkategori_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT menu_idkategori_fkey FOREIGN KEY (idkategori) REFERENCES kategori(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pembelian_bahan_baku_idkaryawan_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY pembelian_bahan_baku
    ADD CONSTRAINT pembelian_bahan_baku_idkaryawan_fkey FOREIGN KEY (idkaryawan) REFERENCES karyawan(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pembelian_bahan_baku_idsupplier_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY pembelian_bahan_baku
    ADD CONSTRAINT pembelian_bahan_baku_idsupplier_fkey FOREIGN KEY (idsupplier) REFERENCES supplier(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pembelian_bahan_baku_namabahan_fkey; Type: FK CONSTRAINT; Schema: siresto; Owner: postgres
--

ALTER TABLE ONLY pembelian_bahan_baku
    ADD CONSTRAINT pembelian_bahan_baku_namabahan_fkey FOREIGN KEY (namabahan) REFERENCES bahan_baku(nama) ON UPDATE CASCADE ON DELETE CASCADE;


SET search_path = sitikop, pg_catalog;

--
-- Name: jadwal_id_film_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY jadwal
    ADD CONSTRAINT jadwal_id_film_fkey FOREIGN KEY (id_film) REFERENCES film(id_film) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pemesanan_email_member_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY pemesanan
    ADD CONSTRAINT pemesanan_email_member_fkey FOREIGN KEY (email_member) REFERENCES member(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pemesanan_id_tiket_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY pemesanan
    ADD CONSTRAINT pemesanan_id_tiket_fkey FOREIGN KEY (id_tiket) REFERENCES tiket(id_tiket) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: seating_no_studio_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY seating
    ADD CONSTRAINT seating_no_studio_fkey FOREIGN KEY (no_studio) REFERENCES studio(no_studio) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tiket_id_jadwal_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY tiket
    ADD CONSTRAINT tiket_id_jadwal_fkey FOREIGN KEY (id_jadwal) REFERENCES jadwal(id_jadwal) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tiket_id_seating_fkey; Type: FK CONSTRAINT; Schema: sitikop; Owner: postgres
--

ALTER TABLE ONLY tiket
    ADD CONSTRAINT tiket_id_seating_fkey FOREIGN KEY (id_seating) REFERENCES seating(id_seating) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

